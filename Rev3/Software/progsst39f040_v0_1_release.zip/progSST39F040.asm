;copy program of same name from RR512K_rev1
; Program resides in 0x8000
; Flash resides in 0x0-0x7FFF
; It chip erase the SST39SF040 first
; Once chip erase is completed, it prompts the user to upload the 512K image file
; The flash will be written as the image file is uploaded
; physical address of flash is 0x800000; physical address of RAM is 0x0
;MMU is set up such that 0x0-0x7FFF always points to physical 0x800000-0x807FFF
;Use memory 0xC000-0xCFFF to map into the appropriate address in EPROM
UARTconf 	equ 10h		; UART configuration register
RxData  	equ 16h        	; on-chip UART receive register
TxData  	equ 18h        	; on-chip UART transmit register
RxStat  	equ 14h        	; on-chip UART transmitter status/control register
TxStat  	equ 12h        	; 0n-chip UART receiver status/control register

MMUctrl	equ 0f0h		; MMU master control reg
MMUptr	equ 0f1h		; MMU page descriptor reg pointer
MMUsel	equ 0f5h		; MMU descriptor select port
MMUmove	equ 0f4h		; MMU block move port
MMUinv	equ 0f2h		; MMU invalidation port

	org 8000h
	jr start
sector:	ds 1
addr3116	ds 2
MMUval	ds 2		;MMU value derived from sector and addr3116
start:
	ld sp,0bfffh

	ld c,08h		;I/O page register
	ld l,0ffh		; set I/O page register to 0xFF
	db 0edh,6eh	; this is the op code for LDCTL (C),HL
;	ldctl (c),hl	; write to I/O page register
;	ld a,0b0h		; initialize the refresh register to 48 counts, 16uS
	ld a,30h		; disable refresh
	out (0e8h),a	; disable refresh

; initialize MMU page descriptors
;0x0-0x7FFF is mapped to EPROM at 0x800000
;MMUtbl is pre initialized in EPROM, so no need to initialize it

	xor a		; clear reg A 
	out (MMUptr),a	; point to this page (page 0x0), user page descriptors	
	ld hl,MMUtbl	; block move MMU page descriptors
	ld c,MMUmove	; points to MMU block move port
	ld b,16		; move 16 pages
	db 0edh,93h	; op code for otirw, output word and increment
;	otirw
	ld a,10h		; repeat the block move for system page descriptors
	out (MMUptr),a	; point to this page (page 0x0), user page descriptors	
	ld hl,MMUtbl	; block move MMU page descriptors
	ld c,MMUmove	; points to MMU block move port
	ld b,16		; move 16 pages
	db 0edh,93h	; op code for otirw, output word and increment
;	otirw
	ld c,MMUctrl	; point to MMU master control register
	ld hl,0bbffh	; enable user & system  translate
	db 0edh,0bfh	; op code for OUTW (C),HL
;	outw (c),hl	; turn on MMU

	call UARTPage
	ld hl,signon$	;send out sign on message
	call strout

	in a,(RxData)	;read flush the character buffer
	call cin		;look for 'Y' for chip erase confirmation
	cp 'Y'
	jp nz,SSTabort	;abort, return to monitor
	call eraseSST	;chip erase

	ld hl,upload$
	call strout

	xor a
	ld (sector),a	;initialize sector to 0
	ld (addr3116),a	;initialize extended address to 0
	ld (addr3116+1),a

loadhex:
	call cinq
	cp ':'			; intel load file starts with :
	jr nz,loadhex
; load Intel file
fileload:
	call GETHEXQ	; get two ASCII char (byte count) into hex byte in reg A
	ld d,a		; save byte count to reg D
	ld c,a		; save copy of byte count to reg C
	ld b,a		; initialize the checksum
	call GETHEXQ	; get MSB of address
	ld h,a		; HL points to memory to be loaded
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get LSB of address
	ld l,a
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the record type, 0 is data, 1 is end
	cp 0
	jp z,filesave
	cp 1		; end of file transfer?
	jp z,fileend
	cp 4		; Extended linear address?
	jp nz,unknown	; if not, print a 'U'
; Extended linear address for greater than 64K
; this is where addr3116 is modified
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld a,d		; byte count should always be 2
	cp 2
	jp nz,unknown
	call GETHEXQ	; get first byte (MSB) of high address
	ld (addr3116+1),a	; save to addr3116+1
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
; Little Endian format.  MSB in addr3116+1, LSB in addr3116
	call GETHEXQ	; get the 2nd byte (LSB) of of high address
	ld (addr3116),a	; save to addr3116
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jp nz,badload	; checksum not match, put '?'
	ld a,'E'		; denote a successful Extended linear addr update

	jp filesav2

; end of the file load
fileend:
	call GETHEXQ	; flush the line, get the last byte
	ld a,'X'		; mark the end with 'X'
	call cout
	ld a,10			; carriage return and line feed
	call cout
	ld a,13
	call cout
	ld hl,SSTdone$	;programming done
	call strout
	jp $		;stop here
; the assumption is the data is good and will be saved to the destination memory
filesave:
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
;compute the MMU value, MMUval, to be written into MMU correspond to 4K page for 0xC000
;The top nibble is 8, the next nibble is low 3 bits of addr 3116, the next nibble is
;  top 4 bits of reg H, and the lowest nibble is value 0xA
	ld a,(addr3116)	;extend address LSB value
	and 7		;keep the low 3 bits
	or 80h		;set bit 7
	ld (MMUval+1),a	;save MSB of MMUval
	ld a,h
	and 0f0h		;keep the top 4 bits of regH
	or 0ah		;set lower 4 bits to 1010b
	ld (MMUval),a	;save LSB of MMUval
		
;compute the sector value
;it is the top 4 bits of reg H concatenated with lower 3 bit of addr3116
	ld a,h		;adjust the pointer to memory range 0xc000-0xCFFF
			;0xC000-0xCFFF is the "window" into EPROM
	and 0fh		;mask off bit 5,4
	or 0c0h		;set bit 6,7
	ld h,a

filesavx:
	call GETHEXQ	; get a byte
	push af		;save
;logical memory 0x0 to 0x7FFF is always map to 0x800000-0x807FFF
	ld a,0aah
	ld (5555h),a	;1st bus write cycle
	ld a,55h
	ld (2aaah),a	;2nd bus write cycle
	ld a,0a0h
	ld (5555h),a	;3rd bus write cycle

	call MMUPage
	push bc
	push hl
	ld a,0ch		;point to User page correspond to 0xc000
	out (MMUptr),a
	ld c,MMUsel
	ld hl,(MMUval)	;get the calculated MMU address
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	ld a,1ch		;point to System page correspond to 0x0
	out (MMUptr),a

	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	call UARTPage
	pop hl
	pop bc
	pop af		;restore
	ld (hl),a		;store value to EPROM
	inc hl
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	dec d
	jp nz,filesavx
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jp nz,badload	; checksum not match, put '?'

	ld a,'.'		; checksum match, put '.'
filesav2:
	call cout
	jp flushln	; repeat until record end
badload:
	ld a,'?'		; checksum not match, put '?'
	jp filesav2
unknown:
	ld a,'U'		; put out a 'U' and wait for next record
	call cout
flushln:
	call cinq		; keep on reading until ':' is encountered
	cp ':'
	jp nz,flushln
	jp fileload

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GETHEX -- Get byte from console as hex
;
;pre: none
;post: A register contains byte from hex input
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GETHEXQ:
	push de		; save register 
        	CALL cinq
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cinq
        	CALL ASCHEX
        	OR D 
  	pop de			;restore register
        	RET
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ASCHEX -- Convert ASCII coded hex to nybble
;
;pre: A register contains ASCII coded nybble
;post: A register contains nybble
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ASCHEX: 	SUB 30h
        	CP 0Ah
        	RET M
        	AND 5Fh
        	SUB 07h
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

SSTfull:
	ld hl,SSTfull$	;put out a message that the entire EPROM is programmed
	call strout
	jp $
SSTabort:
	ld hl,SSTabort$	;put out a message that operation is aborted by user
	call strout
	jp $

eraseSST:
;no need to initialize MMU because 0x0-0x7FFF is already map to EPROM

	ld a,0aah
	ld (5555h),a	;1st bus write cycle
	ld a,55h
	ld (2aaah),a	;2nd bus write cycle
	ld a,80h
	ld (5555h),a	;3rd bus write cycle
	ld a,0aah
	ld (5555h),a	;4th bus write cycle
	ld a,55h
	ld (2aaah),a	;5th bus write cycle
	ld a,10h
	ld (5555h),a	;6th bus write cycle
	ret
; init page i/o reg to point to UART
UARTPage:
	push hl		; save register
	ld l,0feh		; set I/O page register to 0xFE
	jp setpage
; initialize Z280 page i/o reg to point to MMU and DMA
DMAPage:
MMUPage:
	push hl		; save register
	ld l,0ffh		; MMU and DMA page I/O reg is 0xFF
	jp setpage
; init page i/o reg to point to compactflash
ZeroPage:
CFPage:
	push hl		; save register
	ld l,0		; set I/O page register to 0

setpage:
	push bc		; save more reg
	ld c,08h		; reg c points to I/O page register
; reg L is already pre-loaded with correct page value
	db 0edh,6eh	; this is the op code for LDCTL (C),HL
	pop bc		; restore reg
	pop hl
	ret

strout:
;output string pointed by reg HL
	ld a,(hl)		
	or a		;test for null terminator
	ret z
	call cout		;put out the character in reg a
	inc hl		;get next character
	jr strout

cout:
;output character in reg A
	push af		;save
cout1:
	in a,(TxStat)	;get CPLD serial port status
	and 1		;test TxEmpty bit
	jr z,cout1
	pop af		;restore
	out (TxData),a	;send the character out
	ret
cin:
;input character in reg A
	in a,(RxStat)	;get CPLD serial port status
	and 10h		;data ready flag in d[0]
	jr z,cin
	in a,(RxData)	;read character
	out (TxData),a	;echo back
	ret
cinq:
;input character in reg A, no echo back
	in a,(RxStat)	;get CPLD serial port status
	and 10h		;data ready flag in d[0]
	jr z,cinq
	in a,(RxData)	;read character
	ret
MMUtbl	db 0ah,80h,1ah,80h,2ah,80h,3ah,80h,4ah,80h,5ah,80h,6ah,80h,7ah,80h
	db 8ah,0h,9ah,0h,0aah,0h,0bah,0,0cah,0h,0dah,0h,0eah,0h,0fah,0h

signon$:	db 0ah,0dh,"ZZ80MB Programmer for SST39SF040 ver 0.1 10/1220"
	db 0ah,0dh,"SST39SF040 will now be erased"
	db 0ah,0dh,"Enter Y to proceed, all other keys to abort ",0
upload$:	db 0ah,0dh,"SST39SF040 erased, ready to upload the image file"
	db 0ah,0dh,0
SSTfull$:	db 0ah,0dh,"SST39SF040 is full"
SSTdone$:	db 0ah,0dh,"Programming is done",0
SSTabort$:db 0ah,0dh,"Operation aborted by user",0

	end
